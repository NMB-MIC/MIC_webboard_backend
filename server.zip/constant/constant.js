module.exports =
{
    kResultOk: 'ok',
    kResultNok: 'nok',
    frontEndIP: "http://10.121.1.123:8000/",
    NOT_CONNECT_NETWORK: 'NOT_CONNECT_NETWORK',
    NETWORK_CONNECTION_MESSAGE: 'Cannot connect to server, Please try again.'
}

